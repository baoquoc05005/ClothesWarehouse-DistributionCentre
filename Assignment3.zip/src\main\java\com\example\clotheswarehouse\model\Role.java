package com.example.clotheswarehouse.model;

public enum Role {
    ROLE_ADMIN,
    ROLE_WAREHOUSE_EMPLOYEE,
    ROLE_USER
}
