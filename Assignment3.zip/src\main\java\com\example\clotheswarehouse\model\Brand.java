package com.example.clotheswarehouse.model;

public enum Brand {
    BALENCIAGA,
    STONE_ISLAND,
    DIOR
}
